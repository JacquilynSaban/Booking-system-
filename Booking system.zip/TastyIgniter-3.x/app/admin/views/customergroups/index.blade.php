<div class="row-fluid">
    {!! $this->renderList() !!}
</div>
