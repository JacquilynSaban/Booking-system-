<div class="row-fluid">
    {!! $this->widgets['mediamanager']->render() !!}
</div>
