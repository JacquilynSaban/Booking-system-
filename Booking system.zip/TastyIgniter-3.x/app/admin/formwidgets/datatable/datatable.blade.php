<div
    id="{{ $dataTableId }}"
    class="field-datatable size-{{ $size }}"
    data-control="datatable"
>

    {!! $table->render() !!}

</div>

